#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <signal.h>

#if defined (SUNOS)
#include <strings.h>
#endif

#include "macro.h"
#include "conf.h"
#include "dist.h"
#include "trans.h"
#include "move.h"
#include "swap.h"
#include "zwiep.h"

char *program;
int term = 0;

void sig_term(int) { term = 1; }

static char
version[] = "%s: Compiled for %s on %s by TSP\n";

static char
usage[] = "usage: %s [options]\n";

static char
help[] =
  "usage: %s [options]\n"
  "  -l <file>     use <file> for initialization [%s]\n"
  "  -s <file>     use <file> for output routes [%s]\n"
  "  -c <num>      save cutoff value [%d]\n"
  "  -i <num>      do <num> zwiep cycles before reinitialization [%d]\n"
  "  -x <num>      zwiep radius lower bound [%d]\n"
  "  -y <num>      zwiep radius upper bound [%d]\n"
  "  -z <percent>  zwiep continuation chance [%d]\n"
  "  -r <percent>  percent random instead of best [%d]\n"
  "  -h            show this help information and exit\n"
  "  -v            show version information and exit\n";

static char
short_opt[] = "Dl:s:i:r:c:x:y:z:hv";

void
parse_opt(int argc, char *argv[])
{
  extern char *optarg;
  int opt;

  program = rindex(argv[0], '/');
  program = (program ? program + 1 : argv[0]);

  while ((opt = getopt(argc, argv, short_opt)) != EOF)
    switch(opt)
    {
      case 'D': debug = 1; break;
      case 'l': loadfile = optarg; break;
      case 's': savefile = optarg; break;
      case 'r': percent = MIN(MAX(atoi(optarg), 0), 100); break;
      case 'c': cutoff = MAX(atoi(optarg), 0); break;
      case 'i': zinit = MAX(atoi(optarg), 0); break;
      case 'x': zlow = MAX(atoi(optarg), 0); break;
      case 'y': zhigh = MAX(atoi(optarg), 0); break;
      case 'z': zchance = MAX(atoi(optarg), 0); break;
      case 'h':
        printf(help, program,
          DF_LOADFILE ? DF_LOADFILE : "none",
          DF_SAVEFILE ? DF_SAVEFILE : "none",
          DF_CUTOFF, DF_ZINIT, DF_ZLOW, DF_ZHIGH, DF_ZCHANCE, DF_PERCENT
        );
        exit(0);
      case 'v': printf(version, program, MAKE_OS, MAKE_DATE); exit(0);
      case '?':
      default: printf(usage, program); exit(1);
    }
  if (!zinit) zinit = DF_ZINIT;
  if (!zlow) zlow = DF_ZLOW;
  if (!zhigh) zhigh = DF_ZHIGH;
  if (!zchance) zchance = DF_ZCHANCE;
  if (zlow > zhigh) { int t = zlow; zlow = zhigh; zhigh = t; }
}

bool
save_plan(t_plan &plan)
{
  if (savefile)
  {
    ofstream out(savefile, ios::out);
    if (!out.good()) return FALSE;
    out << plan;
    out.close();
    if (debug) 
      cout << "SAVE: saved plan to " << loadfile << endl <<
        "COST: " << plan.cost << endl;
  return TRUE;
  }
  else cout << plan;
  return TRUE;
}

bool
load_plan(t_plan &plan)
{
  ifstream in(loadfile, ios::in);
  if (!in.good()) return FALSE;
  in >> plan;
  in.close();
  if (debug) 
    cout << "LOAD: loaded plan from " << loadfile << endl <<
      "COST: " << plan.cost << endl;
  return TRUE;
} 

int
main(int argc, char *argv[])
{
  t_plan plan;
  t_move move;
  t_swap swap;
  t_zwiep zwiep;
  t_cost best(INT_MAX);
  t_trans::plan = &plan;
  t_trans::t_type type;
  int i, b; 

  INIT_DST; INIT_RND;

  signal(SIGTERM, &sig_term);
  parse_opt(argc, argv);

  while (!term)
  {
    i = zinit; 
    
    if (!load_plan(plan)) plan.random(); 
    while (i--)
    {
      if (RND(100) < percent) type = t_trans::random; else type = t_trans::best;
      do
      {
        b = 0;
        while (move.find(type)) { b++; move.make(); }
        while (swap.find(type)) { b++; swap.make(); }
      }
      while (b);
      if (plan.cost < best) 
      { 
        best = plan.cost; 
        if (plan.cost.max() <= cutoff) save_plan(plan); 
      }
      if (i) do zwiep.make(); while (RND(100) < zchance); 
    }
  }
  signal(SIGTERM, SIG_DFL);

  return 0;
}

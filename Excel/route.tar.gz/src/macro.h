#ifndef __MACROS_H__
#define __MACROS_H__

#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <time.h>

#define FALSE		0
#define TRUE		(!FALSE)

#ifndef RAND_MAX
#define RAND_MAX	INT_MAX
#endif

#define RND(a)		((int)(((double)(a) * rand()) / (RAND_MAX + 1.0)))
#define INIT_RND	srand(time(0) * getpid())

#define ABS(a)		((a) > 0 ? (a) : -(a))
#define MAX(a, b)	((a) > (b) ? (a) : (b))
#define MIN(a, b)	((a) < (b) ? (a) : (b))
#define SQR(a)		((a) * (a))

#endif

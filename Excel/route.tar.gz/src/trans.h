#ifndef __TRANS_H__
#define __TRANS_H__

#include "macro.h"
#include "plan.h"

#define NXT(p)		plan->point[p].next
#define PRV(p)		plan->point[p].prev
#define PTS(r)		plan->points[r]
#define LEN(r)		plan->cost.route(r)
#define CMAX		plan->cost.max()
#define COST		plan->cost

inline bool
anneal(t_cost &a, t_cost &b)
{
  int n = ABS(b.max() - a.max()) + 1;
  if (!RND(n * n * n)) return TRUE; else return FALSE;
}

class t_trans
{
  public:
    t_trans() { selected = 0; }
    static t_plan *plan;
    enum t_type { best, random, annealing, any };
    virtual int find(t_type type) = 0;
    virtual void make() = 0;
  protected:
    bool accept(t_type type);
    t_cost scost, cost;
    int selected, good, bad;
};

t_plan *t_trans::plan = 0;

inline bool
t_trans::accept(t_type type)
{
  switch (type)
  {
    case best:   
      if (cost < scost) { good++; return TRUE; } break;
    case random: 
      if ((cost < COST) && (!RND(good++))) return TRUE; break;
    case annealing:
      if ((anneal(COST, cost)) && (!RND(good++))) return TRUE; break;
    case any:
      if (!RND(good++)) return TRUE; break;
  }
  return FALSE;
}

#endif

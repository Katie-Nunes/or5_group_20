#ifndef __DIST_H__
#define __DIST_H__

#include "macro.h"
#include "conf.h"

#define RP(x)		MAX(x - ROUTES + 1, 0)
#define INIT_DST	init_dist()
#define DST(a, b)	dist[a][b]

#define XDST(a, b)	(ABS(c_x[RP(a)] - c_x[RP(b)]))
#define YDST(a, b)	(ABS(c_y[RP(a)] - c_y[RP(b)]))
#define SCDST(a, b)	(SQR(XDST(a, b)) + SQR(YDST(a, b)))

int dist[ROUTES + POINTS][ROUTES + POINTS];

void
init_dist()
{
  int a, b;
  for (int p1 = 0; p1 < ROUTES + POINTS; p1++)
  {
    a = RP(p1);
    for (int p2 = 0; p2 < ROUTES + POINTS; p2++)
    {
      b = RP(p2);
      if (b) dist[p1][p2] = ABS(c_x[a] - c_x[b]) + ABS(c_y[a] - c_y[b]);
      else dist[p1][p2] = 0;
    }
  }
}

#endif
      

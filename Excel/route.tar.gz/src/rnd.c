#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

#include "macro.h"

int
main(int argc, char *argv[])
{
  srand(time(0) * getpid());

  if (argc < 2)
  {
    printf("usage: rnd <high | low high>\n");
    exit(1);
  }

  int a = atoi(argv[1]);
  if (argc < 3)
  {
    printf("%d\n", RND(atoi(argv[1])));
    exit(0);
  }

  int b = atoi(argv[2]);
  printf("%d\n", a + RND(b - a + 1));
  return 0;
}

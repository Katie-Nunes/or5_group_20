#include <stdio.h>
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>

#include "macro.h"
#include "conf.h"
#include "dist.h"
#include "plan.h"

#define SED		"sed"
#define GNU_PLOT	"gnuplot"

t_plan plan;

void
quit(int code)
{
  char plot[256];
  for (int r = 0; r < ROUTES; r++)
  {
    sprintf(plot, "rm -f /tmp/plot.%d", r);
    system(plot);
  }
  system("rm -f /tmp/plot.gpt /tmp/plot.tmp /tmp/plot.sed");
  exit(code);
}

void
usage(char *program)
{
  fprintf(stderr, "usage: %s <sourcefile> [destfile]\n", program);
  exit(1);
}
 
void
scan(char *source)
{
  ifstream s(source, ios::in);
  if (!s.good()) { perror(source); quit(1); }
  s >> plan;
  s.close();
}

void
make_plot_script()
{
  ofstream f("/tmp/plot.gpt", ios::out | ios::noreplace, 0600);
  if (!f.good()) { perror("/tmp/plot.gpt"); quit(1); }

  f << "set terminal postscript landscape" << endl;
  f << "set output \"/tmp/plot.tmp\"" << endl;
  f << "set data style linespoint" << endl;
  f << "set key 610, 100" << endl;
  f << "set size 0.78, 1" << endl;
  f << "set title \"Manhattan Project (" << plan.cost.max() << ", " <<
    plan.cost.sum() << ")\"" << endl;

  f << "set label \"LABEL D\" at " << c_x[DEPOT] << ", " << c_y[DEPOT] <<
    "center" << endl;

  for (int i = 1; i <= POINTS; i++)
    f << "set label \"LABEL " << i << "\" at " << c_x[i] << ", " << 
      c_y[i] - 2 << " center" << endl;

  f << "plot [0:500] [0:500] \\" << endl;

  for (int r = 0; r < ROUTES - 1; r++)
    f << "  \"/tmp/plot." << r << "\" title \"route " << r << " (" <<
      plan.cost.route(r) << ")\", \\" << endl;

  f << "  \"/tmp/plot." << ROUTES - 1 << "\" title \"route " << ROUTES - 1 
    << " (" << plan.cost.route(ROUTES - 1) << ")\"" << endl;

  f.close();
}

void
make_plot_files()
{
  char plot[64];
  ofstream f;
  int p;

  for (int r = 0; r < ROUTES; r++)
  {
    sprintf(plot, "/tmp/plot.%d", r);
    f.open(plot, ios::out | ios::noreplace, 0600);
    if (!f.good()) { perror(plot); quit(1); }
    f << c_x[DEPOT] << " " << c_y[DEPOT] << endl; p = 0;
    p = plan.point[r].next; 
    while (p != r) 
    {
      f << c_x[RP(p)] << " " << c_y[RP(p)] << endl;
      p = plan.point[p].next;
    }
    f.close();
  }
}

void
make_plot(char *dest)
{
  char plot[256];

  ofstream f("/tmp/plot.sed", ios::out | ios::noreplace, 0600);
  if (!f.good()) { perror("/tmp/plot.sed"); quit(1); }
  f << "/Lshow/i\\" << endl;
  f << "/Pshow { /Helvetica findfont 40 scalefont setfont \\" << endl;
  f << "  currentpoint stroke M dup stringwidth pop -2 div vshift R show \\";
  f << endl << "  /Helvetica findfont 140 scalefont setfont } def" << endl;
  f << "/(LABEL \\(.*\\)) Cshow/s//(\\1) Pshow/g" << endl;
  f.close();

  sprintf(plot, "/tmp/plot.tmp");
  f.open(plot, ios::out | ios::noreplace, 0600);
  if (!f.good()) { perror(plot); quit(1); }
  f.close();

  sprintf(plot, "%s /tmp/plot.gpt", GNU_PLOT);
  system(plot);
  sprintf(plot, "%s -f /tmp/plot.sed /tmp/plot.tmp > %s", SED, dest);
  system(plot);
}

int
main(int argc, char *argv[])
{
  INIT_DST;
  if (argc < 2) usage(argv[0]);
  scan(argv[1]);
  if (plan.verify() != VF_OK) { cerr << "incorrect plan" << endl; quit(1); }
  if (argc < 3) { cout << plan.cost << endl; return 0; }
  make_plot_script();
  make_plot_files();
  make_plot(argv[2]);
  quit(0);
}

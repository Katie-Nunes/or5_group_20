#ifndef __RSEQ_H__
#define __RSEQ_H__

#include "macro.h"

class t_rseq
{
  public:
    t_rseq(int n);
    ~t_rseq() { delete [] seq; }
    int operator () () { return next(); }
  protected:
    int next();
    int size, *seq;
};

t_rseq::t_rseq(int n)
{
  seq = new int [size = n];
  for (int i = 0; i < size; i++) seq[i] = i;
}

int
t_rseq::next()
{
  if (!size) return -1;

  int n = RND(size), v = seq[n];
  seq[n] = seq[--size];
  return v;
}

#endif

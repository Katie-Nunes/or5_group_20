#ifndef __PLAN_H__
#define __PLAN_H__

#include <iostream.h>

#include "macro.h"
#include "rseq.h"
#include "conf.h"
#include "dist.h"
#include "cost.h"

#define VF_OK 	        0
#define VF_POINT 	1
#define VF_PREV 	2
#define VF_NEXT 	3
#define VF_DUPLICATE 	4
#define VF_PREVNEXT 	5
#define VF_NEXTPREV 	6
#define VF_MISSING 	7

static
char *vf_msg[8] = 
{
  "no errors detected",
  "invalid point in route",
  "next link invalid",
  "previous link invalid",
  "duplicate point detected",
  "next field of previous point incorrect",
  "prev field of next point incorrect",
  "missing point detected"
};
 
#define INVALID(p)	((p < 0) || (p >= ROUTES + POINTS))

struct t_point { int prev, next; };

class t_plan
{
  public:
    friend istream &operator >> (istream &s, t_plan &p);
    void random();
    void fix();
    int verify();
    t_point point[ROUTES + POINTS];
    int points[ROUTES];
    t_cost cost;
};

void 
t_plan::random()
{
  t_rseq ps(POINTS);
  int r, p;

  for (r = 0; r < ROUTES; r++)
  {
    point[r].prev = point[r].next = p = ps() + ROUTES;
    point[p].prev = r; points[r] = 1;
  }

  while ((p = ps() + ROUTES) >= ROUTES)
  {
    r = RND(ROUTES); points[r]++;
    point[point[r].prev].next = p;
    point[p].prev = point[r].prev;
    point[r].prev = p;
  }

  for (r = 0; r < ROUTES; r++) point[point[r].prev].next = r;

  fix();
}

void
t_plan::fix()
{
  int r, p, l;

  cost.set(-1, 0);
  for (r = 0; r < ROUTES; r++)
  {
    p = point[r].next; points[r] = 0; l = 0; 
    while (p != r)
    {
      l += DST(point[p].prev, p);
      cost.inc(-1, l);
      p = point[p].next; points[r]++;
    }
    cost.set(r, l);
  }
}

int
t_plan::verify()
{
  int check[ROUTES + POINTS], p, r;
  t_cost old = cost;

  fix(); if (!(cost == old)) return FALSE;

  for (p = 0; p < ROUTES + POINTS; p++) check[p] = 0;

  for (r = 0; r < ROUTES; r++)
  {
    p = r;
    do
    {
      if (INVALID(p)) return VF_POINT;
      if (INVALID(point[p].prev)) return VF_PREV;
      if (INVALID(point[p].next)) return VF_NEXT;
      if (check[p]) return VF_DUPLICATE;
      if (point[point[p].prev].next != p) return VF_PREVNEXT;
      if (point[point[p].next].prev != p) return VF_NEXTPREV;
      check[p] = 1; p = point[p].next;
    }
    while (p != r);
  }

  for (p = 0; p < ROUTES + POINTS; p++) if (check[p] != 1) return VF_MISSING;

  return VF_OK;
}

ostream &
operator << (ostream &s, t_plan &p)
{
  s << p.cost << endl;
  for (int r = 0; r < ROUTES; r++)
  {
    int t = p.point[r].next;
    while (t != r) { s << t - ROUTES + 1 << " "; t = p.point[t].next; }
    s << "0" << endl;
  }
  return s;
}

istream &
operator >> (istream &s, t_plan &p)
{
  s >> p.cost;
  for (int r = 0; r < ROUTES; r++)
  {
    int t, u = r; s >> t;
    while (t)
    {
      t += ROUTES - 1;
      p.point[t].prev = u; p.point[u].next = t; 
      u = t; s >> t;
    }
    p.point[u].next = r; p.point[r].prev = u;
  }
  p.fix();
  return s;
}

#endif

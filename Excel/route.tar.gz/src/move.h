#ifndef __MOVE_H__
#define __MOVE_H__

#include "macro.h"
#include "conf.h"
#include "dist.h"
#include "cost.h"
#include "trans.h"

class t_move : public t_trans
{
  public:
    virtual int find(t_type type);
    virtual void make();
  protected:
    inline void select(int r1, int r2, int p, int s, int t, int nst);
    void find_normal(t_type type);
    void find_reversed(t_type type);
    int R1, R2, P, S, T, NST;
};

int
t_move::find(t_type type)
{
  scost = cost = plan->cost; selected = good = bad = 0;
  find_normal(type); find_reversed(type);
  return selected;
}

void
t_move::find_normal(t_type type)
{
  int r1, r2, p, s, t, d1, d2, d, da, lds, lst, lpp, npd, nst, nnt;

  for (r1 = 0; r1 < ROUTES; r1++)
    for (r2 = 0; r2 < ROUTES; r2++)
    {
      p = NXT(r1); npd = PTS(r1); lpp = 0;
      while (npd >= 0)
      {
        s = NXT(r2); lds = DST(r2, s); nnt = PTS(r2) - 1;
        while (s != r2)
        {
          t = s; lst = 0; nst = 1;
          if ((r1 == r2) || (CMAX >= LEN(r1) - DST(PRV(p), p) + DST(PRV(p), s)))
            while (t != r2)
            {
              if ((r1 == r2) && (RND(nst))) break;
              if ((NXT(t) == p) || (t == p)) break;
              d1 = DST(PRV(p), s) + lst + DST(t, p) - DST(PRV(p), p);
              if ((r1 != r2) && (CMAX < LEN(r1) + d1 - DST(t, p))) break;

              d2 = DST(PRV(s), NXT(t)) - DST(PRV(s), s) - lst - DST(t, NXT(t));
              d = (r1 == r2 ? (nnt < npd ? -d1 : d2) : 0) - lds + lpp;
              da = d1 * npd + d2 * nnt + (DST(PRV(p), s) + d) * nst;

              cost.inc(r1, d1); cost.inc(r2, d2); cost.inc(-1, da);
              if (accept(type)) select(r1, r2, p, s, t, nst);
              cost.dec(r1, d1); cost.dec(r2, d2); cost.dec(-1, da);

              lst += DST(t, NXT(t)); nst++; nnt--; t = NXT(t);
            }
          lds += DST(s, NXT(s)); nnt += nst - 2; s = NXT(s);
        }
        lpp += DST(PRV(p), p); npd--; p = NXT(p);
      }
    }
}

void
t_move::find_reversed(t_type type)
{
  int r1, r2, p, s, t, u, d1, d2, d, da, lds, lst, lpp, npd, nst, nnt, ast, ats;

  for (r1 = 0; r1 < ROUTES; r1++)
    for (r2 = 0; r2 < ROUTES; r2++)
    {
      p = NXT(r1); npd = PTS(r1); lpp = 0;
      while (npd >= 0)
      {
        s = NXT(r2); lds = DST(r2, s); nnt = PTS(r2) - 2;
        while (s != r2)
        {
          t = NXT(s); lst = ast = ats = DST(s, t); nst = 2;
          if ((r1 == r2) || (CMAX >= LEN(r1) - DST(PRV(p), p) + DST(s, p)))
            while (t != r2)
            {
              if ((r1 == r2) && (RND(nst))) break;
              if ((t == p) || (t == NXT(p))) break;
              u = (NXT(t) == p ? PRV(s) : PRV(p));
              d1 = DST(u, t) + lst + DST(s, p) - DST(u, p);
              if ((r1 != r2) && (CMAX < LEN(r1) + d1 - DST(u, t))) break;

              d2 = DST(PRV(s), NXT(t)) - DST(PRV(s), s) - lst - DST(t, NXT(t));
              d = (r1 == r2 ? (nnt < npd ? -d1 : (nnt == npd ? - lst - 
                DST(u, s) : d2)) : 0) + DST(u, t) - lds + lpp;
              da = ats - ast + d1 * npd + d2 * nnt + d * nst;

              cost.inc(r1, d1); cost.inc(r2, d2); cost.inc(-1, da);
              if (accept(type)) select(r1, r2, p, s, t, -nst);
              cost.dec(r1, d1); cost.dec(r2, d2); cost.dec(-1, da);

              lst += DST(t, NXT(t)); ast += lst; ats += nst * DST(t, NXT(t)); 
              nst++; nnt--; t = NXT(t);
            }
          lds += DST(s, NXT(s)); nnt += nst - 3; s = NXT(s);
        }
        lpp += DST(PRV(p), p); npd--; p = NXT(p);
      }
    }
}

void 
t_move::make() 
{ 
  if (!selected) 
  {
    cerr << "ERROR: no transformation selected before call to make()" << endl;
    exit(1);
  }

  if (debug)
  {
    cout << "MOVE: ";
    if (NST < 0)
      cout << "reversed " << R2 << ":[" << RP(S) << "," << RP(T) << "] (" 
        << -NST << ") before " << R1 << ":" << RP(P);
    else if (NST == 1)
      cout << "point " << R2 << ":" << RP(S) << " before " << R1 
        << ":" << RP(P);
    else
      cout << "segment " << R2 << ":[" << RP(S) << "," << RP(T) << "] (" 
        << NST << ") before " << R1 << ":" << RP(P);
    cout << endl << "COST: " << scost << endl;
  }

  if (NST > 0)
  {
    NXT(PRV(S)) = NXT(T); PRV(NXT(T)) = PRV(S); PTS(R2) -= NST;
    NXT(PRV(P)) = S; PRV(S) = PRV(P); NXT(T) = P; PRV(P) = T; PTS(R1) += NST;
  }
  else
  {
    NXT(PRV(S)) = NXT(T); PRV(NXT(T)) = PRV(S); PTS(R2) += NST;
    int t = T, u = (PRV(P) == T ? PRV(S) : PRV(P)), l; 
    NXT(u) = T; PRV(S) = P; PRV(P) = S; PTS(R1) -= NST; 
    while (u != S) { l = NXT(t) = PRV(t); PRV(t) = u; u = t; t = l; } 
  }
 
  COST = scost;
  selected = 0;
}

inline void
t_move::select(int r1, int r2, int p, int s, int t, int nst)
{
  R1 = r1; R2 = r2; P = p; S = s; T = t; NST = nst; scost = cost; selected++;
}

#endif

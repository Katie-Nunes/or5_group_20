#ifndef __COST_H__
#define __COST_H__

#include <iostream.h>
#include <limits.h>

#include "macro.h"
#include "conf.h"

class t_cost
{
  public:
    t_cost(int init = 0);
    friend istream &operator >> (istream &s, t_cost &c);
    int route(int r) { return (r < 0) || (r >= ROUTES) ? 0 : Route[r]; }
    int max() { return Update ? get_max() : Max; }
    int sum() { return Sum; }
    void set(int r, int d);
    void inc(int r, int d) { set(r, r < 0 ? sum() + d : route(r) + d); }
    void dec(int r, int d) { set(r, r < 0 ? sum() - d : route(r) - d); }
  protected:
    int get_max();
    bool Update;
    int Route[ROUTES], Max, Sum;
};

t_cost::t_cost(int init = 0)
{
  Max = Sum = init; Update = FALSE;
  for (int r = 0; r < ROUTES; r++) Route[r] = init;
}

void
t_cost::set(int r, int d)
{
  if (r < 0) Sum = d; else if (r < ROUTES) { Route[r] = d; Update = TRUE; }
}

int
t_cost::get_max()
{
  Update = FALSE; Max = INT_MIN;
  for (int r = 0; r < ROUTES; r++) Max = MAX(Max, Route[r]);
  return Max;
}

int
operator == (t_cost &a, t_cost &b)
{
  for (int r = 0; r < ROUTES; r++)
    if (a.route(r) != b.route(r)) return FALSE;
  if (a.sum() != b.sum()) return FALSE;
  return TRUE;
}

inline int
operator < (t_cost &a, t_cost &b)
{
  return (a.max() < b.max()) || ((a.max() == b.max()) && (a.sum() < b.sum()));
}

ostream &
operator << (ostream &s, t_cost &c)
{
  for (int r = 0; r < ROUTES; r++) s << c.route(r) << " ";
  s << c.max() << " " << c.sum();
  return s;
}

istream &
operator >> (istream &s, t_cost &c)
{
  c.Max = INT_MIN; c.Update = FALSE;
  for (int r = 0; r < ROUTES; r++)
    { s >> c.Route[r]; c.Max = MAX(c.Max, c.Route[r]); }
  s >> c.Max; s >> c.Sum;
  return s;
}

#endif

#ifndef __ZWIEP_H__
#define __ZWIEP_H__

#include "macro.h"
#include "conf.h"
#include "dist.h"
#include "cost.h"
#include "trans.h"

class t_zwiep : public t_trans
{
  public:
    virtual int find(t_type) { return TRUE; };
    virtual void make();
};

void 
t_zwiep::make() 
{ 
  int in[POINTS / 2], i = 0, pt[POINTS], p = 0, r, q, f;
  int center = RND(POINTS) + ROUTES, radius = ZRAD; 

  for (r = 0; r < ROUTES; r++)
  {
    q = NXT(r); f = 0;
    while (q != r)
    {
      if (SCDST(center, q) < SQR(radius))
        { if (!f) { in[i++] = PRV(q); f = 1; } pt[p++] = q; }
      else f = 0;
      q = NXT(q);
    }
  }

  if (debug)
    cout << "ZWP:  center " << RP(center) << ", radius " << radius <<
      ", segments " << i << ", points " << p << endl;

  t_rseq ps(p);
  while ((p = ps()) >= 0)  
  {
    NXT(PRV(pt[p])) = NXT(pt[p]); PRV(NXT(pt[p])) = PRV(pt[p]);
    r = RND(i);
    NXT(pt[p]) = NXT(in[r]); PRV(pt[p]) = in[r];
    NXT(in[r]) = pt[p]; PRV(NXT(pt[p])) = pt[p];
  }

  plan->fix();

  if (debug) cout << "COST: " << plan->cost << endl;
}

#endif

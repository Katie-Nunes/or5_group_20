#ifndef __SWAP_H__
#define __SWAP_H__

#include "macro.h"
#include "conf.h"
#include "dist.h"
#include "cost.h"
#include "trans.h"

class t_swap : public t_trans
{
  public:
    virtual int find(t_type type);
    virtual void make();
  protected:
    inline void select
      (int r1, int r2, int p, int q, int s, int t, int npq, int nst);
    void find_normal(t_type type);
    int R1, R2, P, Q, S, T, NPQ, NST;
};

int
t_swap::find(t_type type)
{
  scost = cost = plan->cost; good = bad = 0;
  find_normal(type); 
  return selected;
}

void
t_swap::find_normal(t_type type)
{
  int r1, r2, p, q, s, t, d1, d2, da, ldp, lds, lpq, lst, npq, nst, nnq, nnt;

  for (r1 = 0; r1 < ROUTES; r1++)
    for (r2 = r1 + 1; r2 < ROUTES; r2++)
    {
      p = NXT(r1); ldp = DST(r1, p); nnq = PTS(r1) - 1;
      while (p != r1)
      {
        q = p; lpq = 0; npq = 1;
        while (q != r1)
        {
          s = NXT(r2); lds = DST(r2, s); nnt = PTS(r2) - 1;
          while (s != r2)
          {
            t = s; lst = 0; nst = 1;
            while (t != r2)
            {
              d1 = DST(PRV(p), s) + lst + DST(t, NXT(q));
              d1 -= DST(PRV(p), p) + lpq + DST(q, NXT(q));
              if (CMAX < LEN(r1) + d1 - DST(t, NXT(q))) break;
              d2 = DST(PRV(s), p) + lpq + DST(q, NXT(t));
              d2 -= DST(PRV(s), s) + lst + DST(t, NXT(t));
              if (CMAX >= LEN(r2) + d2)
              {
                da = nnq * d1 - npq * ldp + nst * (ldp - DST(PRV(p), p) +
                  DST(PRV(p), s)) + nnt * d2 - nst * lds + npq * (lds -
                  DST(PRV(s), s) + DST(PRV(s), p));
          
                cost.inc(r1, d1); cost.inc(r2, d2); cost.inc(-1, da);
                if (accept(type)) select(r1, r2, p, q, s, t, npq, nst);
                cost.dec(r1, d1); cost.dec(r2, d2); cost.dec(-1, da);
              }
              lst += DST(t, NXT(t)); nst++; nnt--; t = NXT(t);
            }
            lds += DST(s, NXT(s)); nnt += nst - 2; s = NXT(s);
          }
          lpq += DST(q, NXT(q)); npq++; nnq--; q = NXT(q);
        }
        ldp += DST(p, NXT(p)); nnq += npq - 2; p = NXT(p);
      } 
    }
}

void 
t_swap::make() 
{ 
  if (!selected) 
  {
    cerr << "ERROR: no transformation selected before call to make()" << endl;
    exit(1);
  }

  if (debug)
  {
    cout << "SWAP: ";
    if (NPQ == 1) 
      cout << "point " << R1 << ":" << RP(P); 
    else 
      cout << "segment " << R1 << ":[" << RP(P) << "," << RP(Q) << "] (" 
        << NPQ << ")";
    cout << " with ";
    if (NST == 1) 
      cout << "point " << R2 << ":" << RP(S); 
    else
      cout << "segment " << R2 << ":[" << RP(S) << "," << RP(T) << "] (" 
        << NST << ")";
    cout << endl << "COST: " << scost << endl;
  }
  
  int u;

  NXT(PRV(P)) = S; PRV(NXT(Q)) = T; PTS(R1) += NST - NPQ;
  NXT(PRV(S)) = P; PRV(NXT(T)) = Q; PTS(R2) += NPQ - NST;
  u = PRV(S); PRV(S) = PRV(P); PRV(P) = u;
  u = NXT(T); NXT(T) = NXT(Q); NXT(Q) = u;
  
  COST = scost;
  selected = 0;
}

inline void
t_swap::select(int r1, int r2, int p, int q, int s, int t, int npq, int nst)
{
  R1 = r1; R2 = r2; P = p; Q = q; S = s; T = t; NPQ = npq; NST = nst; 
  scost = cost; selected++;
}

#endif
